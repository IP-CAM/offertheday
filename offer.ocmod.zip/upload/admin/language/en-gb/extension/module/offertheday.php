<?php
// Heading
$_['heading_title']        = 'Offer the day';
					       
// Text                    
$_['text_extension']       = 'Extensions';
$_['text_success']         = 'Success: You have modified Offer the day module!';
$_['text_edit']            = 'Edit Offer the day Module';

//button
$_['button_setting']       = 'Module settings';

// Entry
$_['entry_product']        = 'Products';
$_['entry_customer_group'] = 'Customer Group';
$_['entry_status']         = 'Status';
$_['entry_date_start']     = 'Date Start';
$_['entry_date_end']       = 'Date End';
$_['entry_priority']       = 'Priority';

// Help
$_['help_product']         = '(Autocomplete)';

// Error
$_['error_fill']     = 'Warning: Check the data entry!';

